#include "dictionary.h"
#include "grid.h"
#include "iostream"
#include "fstream"
#include "d_matrix.h"
#include "d_except.h"
#include "main.h"
#include <string>


using namespace std;

int main()
{
   search();
   return 0;
}
